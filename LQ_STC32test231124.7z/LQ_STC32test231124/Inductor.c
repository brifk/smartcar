#include "include.h"

int pwm_l, pwm_r;
int MotorDuty1 = 0;
int MotorDuty2 = 0;
int count = 0;
int speed_error;
int L_rpm, R_rpm, current_speed, target_speed = 90;
int Feedback_Speed_L = 0, Feedback_Speed_R = 0;
long int Feedback_Speed_tmp_L, Feedback_Speed_tmp_R;
int distanse = 0;
int speed = 0;
float angle = 0;
float L_Angle = 230, R_Angle = 210;
int dis_count = 0;
int show_count = 0;

int16 Inductor[4];
int16 left_V;
int16 left_P;
int16 right_V;
int16 right_P;
int16 sum_V;
int16 sum_P;
int16 Error_V;
int16 Error_P;

float zhi_KP = 15.4, zhi_KD = 1.66, zhi_KI = 0.10;           // ֱ��PID
float Direction_KP = 10, Direction_KD = 2, Direction_KI = 0; // ת��PID
float Direction_integrator = 0;
float last_error = 0;
float PWM;

uint8_t key_flag = 1; // ��Ļ���α�־λ
unsigned char dis_buff[2];
uint16 dis, last_dis = 0;

short Direction_PWM = 0; // ת�����
short L90_PWM = 1550, R90_PWM = 1450;
int ECPULSE1 = 0;
int ECPULSE2 = 0;
int sum_ECPULSE1 = 0;
int sum_ECPULSE2 = 0;

int L_flag = 0, R_flag = 0; // ����־
int runmod = 0;             // ����ģʽ
short Go = 0;               // ���뿪�ؼ��
short benhuan_count = 0;    // ��������
pid_param_t pid2;

void PID2_Init() // �ٶȻ�PID��ʼ��
{
    PidInit(&pid2);
    pid2.kp = 17;
    pid2.ki = 1.5;
    pid2.kd = 4;
}

void Inductor_Car(void)
{
    Pin_Init(); // ϵͳ���ų�ʼ��
    while (1)
    {
        OLED_show();         // ��Ļ��ʾ
        if (!KEY_Read(KEY0)) // K0������ȡ
        {
            switch (key_flag)
            {
            case 1:
                zhi_KP += 0.1;
                break;
            case 2:
                zhi_KI += 0.01;
                break;
            case 3:
                zhi_KD += 0.1;
                break;
            case 4:
                target_speed += 1;
                break;
            case 5:
                L90_PWM += 50;
                break;
            case 6:
                R90_PWM += 50;
                break;
            case 7:
                L_Angle += 10;
                break;
            case 8:
                R_Angle += 10;
                break;
            }
            delayms(100);
        }
        if (!KEY_Read(KEY1)) // K1������ȡ
        {
            switch (key_flag)
            {
            case 1:
                zhi_KP -= 0.1;
                break;
            case 2:
                zhi_KI -= 0.01;
                break;
            case 3:
                zhi_KD -= 0.1;
                break;
            case 4:
                target_speed -= 1;
                break;
            case 5:
                L90_PWM -= 50;
                break;
            case 6:
                R90_PWM -= 50;
                break;
            case 7:
                L_Angle -= 10;
                break;
            case 8:
                R_Angle -= 10;
                break;
            }
            delayms(100);
        }
        if (!KEY_Read(KEY2)) // K2������ȡ
        {
            switch (key_flag)
            {
            case 1:
                key_flag = 2;
                break;
            case 2:
                key_flag = 3;
                break;
            case 3:
                key_flag = 4;
                break;
            case 4:
                key_flag = 5;
                break;
            case 5:
                key_flag = 6;
                break;
            case 6:
                key_flag = 7;
                break;
            case 7:
                key_flag = 8;
                break;
            case 8:
                key_flag = 1;
                break;
            }
            delayms(100);
        }
    }
}

// ��Ļ��ʾ����
void OLED_show(void)
{
    char txt[30];

    // sprintf(txt, "%04d %04d %04d %04d", left_V, left_P, right_P, right_V); // ��ʾ��·��й�һ���?
    sprintf(txt, "%04d %04d %04d %04d", Inductor[0], Inductor[1], Inductor[2], Inductor[3]);
    OLED_P6x8Str(0, 0, (u8 *)txt);

    sprintf(txt, "ERV:%04d ERP:%04d ", Error_V, Error_P); // ��ʾ����?��ֵ
    OLED_P6x8Str(0, 1, (u8 *)txt);

    sprintf(txt, "dis:%04d t_speed:%03d", dis, target_speed); // ��ʾdis&speed
    OLED_P6x8Str(0, 2, (u8 *)txt);

    sprintf(txt, "P:%2.1f I:%2.2f D:%2.1f ", zhi_KP, zhi_KI, zhi_KD); // ��ʾ���PD
    OLED_P6x8Str(0, 3, (u8 *)txt);

    sprintf(txt, "LP:%04d RP:%04d ", L90_PWM, R90_PWM); // 90�ٶ�
    OLED_P6x8Str(0, 4, (u8 *)txt);

    sprintf(txt, "LA:%3.0f RA:%3.0f", L_Angle, R_Angle); // �Ƕ�
    OLED_P6x8Str(0, 5, (u8 *)txt);

    sprintf(txt, "runmod:%01d key:%01d Go:%01d ", runmod, key_flag, Go); // �������α�־λ ��·���PWM
    OLED_P6x8Str(0, 6, (u8 *)txt);

    // printf("%d,%d\n", ECPULSE1, ECPULSE2);
    // printf("%d,%d,%d,%d \n", left_V, left_P, right_V, right_P);
    // printf("%.2f \n", PWM);
    // printf("%d,%d \n", MotorDuty1, MotorDuty2);
    // printf("%d,%d \n", L_rpm, R_rpm);
    // printf("%d,%d \n", L_flag, R_flag);
    // printf("%d,%d \n",pwm_l,pwm_r);
    // printf("%d \n", runmod);
    // printf("%d \n", current_speed);
    // printf("%d \n", dis);
	printf("ax:%d,ay:%d,az:%d,gx:%d,gy:%d,gz:%d \n", aacx, aacy, aacz, gyrox, gyroy, gyroz);
    printf("\n");

    LED_Ctrl(LED0, RVS);
}

int LOW_PASSL(int E1) // ���ֵ�ͨ�˲�
{
    int Feedback_Speed_Now_L;
    int tmp = 10;
    int tmp2 = tmp / 2;
    int tmp7;
    Feedback_Speed_Now_L = E1 * 75 / 64;
    Feedback_Speed_tmp_L += Feedback_Speed_Now_L - Feedback_Speed_L;
    Feedback_Speed_L = Feedback_Speed_tmp_L / tmp;
    tmp7 = Feedback_Speed_tmp_L % tmp;
    if (tmp7 >= tmp2)
        Feedback_Speed_L += 1;
    if (tmp7 <= -tmp2)
        Feedback_Speed_L -= 1;
    return Feedback_Speed_L;
}

int LOW_PASSR(int E2) // ���ֵ�ͨ�˲�
{
    int Feedback_Speed_Now_R;
    int tmp = 10;
    int tmp2 = tmp / 2;
    int tmp7;
    Feedback_Speed_Now_R = E2 * 75 / 64;
    Feedback_Speed_tmp_R += Feedback_Speed_Now_R - Feedback_Speed_R;
    Feedback_Speed_R = Feedback_Speed_tmp_R / tmp;
    tmp7 = Feedback_Speed_tmp_R % tmp;
    if (tmp7 >= tmp2)
        Feedback_Speed_R += 1;
    if (tmp7 <= -tmp2)
        Feedback_Speed_R -= 1;
    return Feedback_Speed_R;
}

// ʹ�ö�ʱ������0��Ϊ�ж�Դ
void timer0_int(void)

    interrupt 1
{

    if (P32 == 1) // ��鲦�뿪��״̬
    {
        Go = 1;
    }
    else
    {
        Go = 0;
    }
    Inductor_Read();
    count += 1;                 // �ٶȻ���������50ms����һ���ٶȻ�����
    ECPULSE1 = Read_Encoder(1); // ��������ȡ
    ECPULSE2 = Read_Encoder(2); // ��������ȡ
    //    sum_ECPULSE1 += ECPULSE1;
    //    sum_ECPULSE2 += ECPULSE2;
    L_rpm = LOW_PASSL(ECPULSE1); // ����������ֵ���е�ͨ�˲��õ�ƽ��ֵ
    R_rpm = -LOW_PASSR(ECPULSE2);

    Gyro_Get_Raw_data_SPI(&aacx, &aacy, &aacz, &gyrox, &gyroy, &gyroz); // ��ȡ������ԭʼֵ
    angle += gyroz * 0.001;                                             // �����ǽǶȻ���
    distanse += current_speed;

    VL53_Read_nByte(VL53ADDR, VL53_REG_DIS, 2, dis_buff); // ���ģ���ȡ����
    dis = (dis_buff[0] << 8) | (dis_buff[1]);             // ����ת��

    if (count >= 10) // 50ms����һ���ٶȻ�����
    {
        current_speed = (L_rpm + R_rpm) / 2;
        speed_error = speed - current_speed;
        PidIncCtrl(&pid2, speed_error);
        pwm_l = pid2.out;
        pwm_r = pid2.out;
        count = 0; // ����ٶȻ�����
        sum_ECPULSE1 = 0;
        sum_ECPULSE2 = 0;
    }

    if (Go == 1) // ���뿪�ز���1���ܽ���Ԫ���ж�
    {
        //        if (dis > 620 && dis < 670)       // ����ж��ϰ�����
        //        {
        //            runmod = 0; // 4
        //            target_speed = 45;
        //            angle = 0;
        //        }
        if (runmod == 0) // �ջ�����
        {
            if (Inductor[1] > 1500 && Inductor[0] < 700 && Inductor[3] < 700) // ��90��
            {
                L_flag = 110; // 90
                R_flag = 0;
                speed = target_speed / 2;
                angle = 0;
                runmod = 1;
            }
            else if (Inductor[2] > 1500 && Inductor[0] < 920 && Inductor[3] < 920) // ��90��
            {
                L_flag = 0;
                R_flag = 90;
                speed = target_speed / 2;
                angle = 0;
                runmod = 2;
            }
            else if (Inductor[1] > 1650 && Inductor[0] > 1300 && Inductor[3] > 1300) // ����
            {
                L_flag = 150;
                R_flag = 150;
                speed = target_speed;
                angle = 0;
                benhuan_count += 1;
                runmod = 3;
            }
            else if (Inductor[0] + Inductor[1] + Inductor[2] + Inductor[3] < 700) // �������
            {

                speed = 0;
                Direction_PWM = 0;
                L_flag = 0;
                R_flag = 0;
            }
            else // ѭ��
            {
                Direction_KP = zhi_KP;
                Direction_KD = zhi_KD;
                Direction_KI = zhi_KI;
                Direction_PWM = Direction_Control(Error_V);
                speed = target_speed;
                L_flag = 1;
                R_flag = 1;
            }
        }

        else if (runmod == 1) // ��90
        {
            Direction_PWM = L90_PWM; // ���̶����ٴﵽ�̶��Ƕ�
            if (angle > L_Angle)
            {
                runmod = 0;
            }
        }
        else if (runmod == 2) // ��90
        {
            Direction_PWM = -R90_PWM;
            if (angle < -R_Angle)
            {
                runmod = 0;
            }
        }
        else if (runmod == 3) // ����
        {
            if (benhuan_count == 1) // ������
            {
                Direction_PWM = 750;
                if (angle > 85)
                {
                    runmod = 0;
                }
            }
            else // ������
            {
                Direction_PWM = 600;
                if (angle > 95)
                {
                    runmod = 0;
                    benhuan_count = 0;
                }
            }
        }
        else if (runmod == 4) // ����
        {
            if (dis_count < 130) // ����ת
            {
                Direction_PWM = 600;
                dis_count += 1;
            }
            else if (dis_count >= 130 && dis_count < 400) // ����ת
            {
                Direction_PWM = -450;
                dis_count += 1;
            }
            else // �ص����ߺ����
            {
                dis_count = 0;
                runmod = 0;
            }
        }
    }

    MotorDuty1 = -pwm_r + Direction_PWM;
    MotorDuty2 = pwm_l + Direction_PWM;

    // �����PWM�޷�
    if (MotorDuty1 > 3500)
        MotorDuty1 = 3500;
    else if (MotorDuty1 < -3500)
        MotorDuty1 = -3500; // �޷�
    if (MotorDuty2 > 3500)
        MotorDuty2 = 3500;
    else if (MotorDuty2 < -3500)
        MotorDuty2 = -3500; // �޷�

    MotorCtrl(MotorDuty1, MotorDuty2); // �����PWM����
}

// ����ģ��ĳ�ʼ��
void Pin_Init(void)
{
    ADC_Init();
    IIC_Init();
    VL53_Write_Byte(VL53ADDR, VL53L0X_REG_SYSRANGE_START, VL53_STAR);
    MotorInit(MOTOR_FREQUENCY);
    Timer34EncInit();
    Timer0_init();
    PID2_Init();
    Soft_SPI_Init();
    //    Gyro_Write_Byte_SPI(ICM_PWR_MGMT1_REG, 0X80); // ��λ
    //    delayms(100);                                 // ��ʱ100ms
    //    Gyro_Write_Byte_SPI(ICM_PWR_MGMT1_REG, 0X00); // ����
    //    delayms(100);                                 // ��ʱ100ms
    Gyro_Write_Byte_SPI(ICM_GYRO_CFG_REG, 3 << 3);
    Gyro_Write_Byte_SPI(ICM_ACCEL_CFG_REG, 1 << 3);
    Gyro_Write_Byte_SPI(ICM_SAMPLE_RATE_REG, 1000 / 999);
    Gyro_Write_Byte_SPI(ICM_CFG_REG, 1);
    Gyro_Write_Byte_SPI(ICM_CFG_REG, 0x02);
    Gyro_Write_Byte_SPI(ICM_INT_EN_REG, 0X00);
    Gyro_Write_Byte_SPI(ICM_USER_CTRL_REG, 0X00);
    Gyro_Write_Byte_SPI(ICM_PWR_MGMT1_REG, 0X01);
    Gyro_Write_Byte_SPI(ICM_PWR_MGMT2_REG, 0X00);
    EA = 1;
    angle = 0;
}

/**************
 * ���ֵ��ȡ
 **************/
void Inductor_Read(void)
{
    // uint8 i;

    /*��ȡ���ε��ֵȡƽ�������˲�*/
    Inductor[0] = (ADC_Read(8) + ADC_Read(8)) / 2;   // ��1
    Inductor[1] = (ADC_Read(9) + ADC_Read(9)) / 2;   // ��2
    Inductor[2] = (ADC_Read(10) + ADC_Read(10)) / 2; // ��2
    Inductor[3] = (ADC_Read(11) + ADC_Read(11)) / 2; // ��1

    // ����?ʼֵ�޷�
    //    for (i = 0; i < 4; i++)
    //    {
    //        if (Inductor[i] < 120)
    //            Inductor[i] = 120;
    //    }

    // ��һ�� ���� �����ֵ��һ��?0~100
    left_V = (float)((Inductor[0] - 130) / (2200.0 - 110.0)) * 100;    // ��ഹֱ�����ߵ��
    left_P = (float)((Inductor[1] - 130.0) / (2200.0 - 105.0)) * 100;  // ���?45��нǵ�в�ֵ
    right_P = (float)((Inductor[2] - 130.0) / (2200.0 - 110.0)) * 100; // �Ҳ�45��нǵ�в�ֵ
    right_V = (float)((Inductor[3] - 130.0) / (2200.0 - 110.0)) * 100; // �Ҳഹֱ�����ߵ��?
    // ��Ⱥͼ����?��
    Error_V = (left_V - right_V) * 100 / (left_V + right_V); // ��ֱ�����ߵ�в��?
    Error_P = (left_P - right_P) * 100 / (left_P + right_P); // 45��нǵ�в�ֵ
    if (Error_V > 100)
        Error_V = 100; // ƫ��ֵ�޷�����?
    else if (Error_V < -100)
        Error_V = -100;       // ƫ��ֵ�޷���Сֵ
    sum_V = left_V + right_V; // ��ֱ�����ߵ�����
    sum_P = left_P + right_P; //  45��нǵ�����?
}

/*********************
 * ������ƺ���?
 * λ��ʸPD����
 *********************/
// int Direction_Control(int error)
// {

//     PWM = Direction_KP * error + Direction_KD * last_error / 10;
//     last_error = error;
//     return (int)PWM;
// }

int Direction_Control(int error)
{
    Direction_integrator += error;
    PWM = Direction_KP * error + Direction_KD * (error - last_error) + Direction_KI * Direction_integrator;
    last_error = error;
    return (int)PWM;
}
