#ifndef __LQ_INDUCTOR_H_
#define __LQ_INDUCTOR_H_
#include "include.h"


void Inductor_Car(void);
void Pin_Init(void);
int Velocity_Control_L(int encoder);
int Velocity_Control_R(int encoder);
void Inductor_Read(void);
void OLED_show(void);
int Direction_Control(int error);

#define VL53L0X_REG_IDENTIFICATION_MODEL_ID         0xc0
#define VL53L0X_REG_IDENTIFICATION_REVISION_ID      0xc2
#define VL53L0X_REG_PRE_RANGE_CONFIG_VCSEL_PERIOD   0x50
#define VL53L0X_REG_FINAL_RANGE_CONFIG_VCSEL_PERIOD 0x70
#define VL53L0X_REG_SYSRANGE_START                  0x00
#define VL53L0X_REG_RESULT_INTERRUPT_STATUS         0x13
#define VL53L0X_REG_RESULT_RANGE_STATUS             0x14
#define VL53_REG_DIS                                0x1E
#define VL53L0X_REG_I2C_SLAVE_DEVICE_ADDRESS        0x8a
#define VL53ADDR                                    0x29    //0x52   Ĭ�ϵ�ַ
#define VL53NEWADDR                                 0x30

void VL53_Read(void);

void VL53_Write_Byte(unsigned char dev, unsigned char reg, unsigned char val);

void VL53_Read_nByte(unsigned char dev, unsigned char reg, unsigned char length, unsigned char* val);



#endif