
#ifndef MYPID_H_
#define MYPID_H_

typedef struct
{
    float kp;   // P
    float ki;   // I
    float kd;   // D
    float imax; // ???????

    float out_p; // KP???
    float out_i; // KI???
    float out_d; // KD???
    float out;   // pid???

    float integrator;      //< ?????
    float last_error;      //< ??????
    float last_derivative; //< ???????????????????
    unsigned long last_t;  //< ??????
} pid_param_t;

void PidInit(pid_param_t *pid);

float constrain_float(float amt, float low, float high);

float PidLocCtrl(pid_param_t *pid, float error);

float PidIncCtrl(pid_param_t *pid, float error);

void PID_ParamConstrain(pid_param_t *pid);

void PID_Clear(pid_param_t *pid);

#endif
