
#ifndef __LQ_ENC_H_
#define __LQ_ENC_H_
#include "include.h"

short Read_Encoder(u8 encno);
void Timer34EncInit(void);
void TestEncoder(void);
void Speedshow(short duty_1, short duty_2, short speed_1, short speed_2);
#endif


