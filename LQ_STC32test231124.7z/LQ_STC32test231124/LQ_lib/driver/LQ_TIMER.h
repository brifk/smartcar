
#ifndef __LQ_TIMER_H_
#define __LQ_TIMER_H_

#include "include.h"
void Timer0_init(void);
void Timer1_init(void);
void Timer2_init(void);
void Timer3_init(void);
void Timer4_init(void);
void delayms(u16 ms);
void delayus(unsigned int us);
#endif
